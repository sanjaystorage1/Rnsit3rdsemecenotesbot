# Rnsit_notes_finder_bot
 Used pyrogram tgcrypto package with python3
 First Bot made to manage the 3rd ECE notes 
 
 refer this website to know about pyrogram package : https://docs.pyrogram.org/intro/setup 
 
 first pip latest has to be installed then,
 pip package name for cmd line :  pip3 install -U pyrogram
 if u want with tgcrypto package then use this cmd line : pip3 install -U pyrogram tgcrypto
 
 then to check the version of pyrogram type cmd : pip show pyrogram
                                            and : pip show tgcrypto
get api_key for ur telegram account using : https://my.telegram.org/apps

then write up the code and start deploying in cloud runner
